import { config } from 'dotenv';
config();

import '@/ai/flows/flag-points-for-inspection.ts';