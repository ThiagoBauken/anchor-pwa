'use server';

/**
 * @fileOverview This file defines a Genkit flow for flagging anchor points that require inspection.
 *
 * - flagPointsForInspection - A function that flags anchor points based on their type, installation date, and previous inspection records.
 * - FlagPointsForInspectionInput - The input type for the flagPointsForInspection function.
 * - FlagPointsForInspectionOutput - The return type for the flagPointsForInspection function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const FlagPointsForInspectionInputSchema = z.object({
  anchorPoints: z.array(
    z.object({
      id: z.string().describe('Unique identifier for the anchor point.'),
      type: z.string().describe('Type of anchor point (e.g., Placa de Ancoragem, Gancho Inox).'),
      installationDate: z.string().describe('Date of installation (YYYY-MM-DD).'),
      lastInspectionDate: z.string().optional().describe('Date of last inspection (YYYY-MM-DD).'),
      inspectionFrequencyMonths: z.number().describe('Inspection frequency in months.'),
    })
  ).describe('Array of anchor point objects.'),
});

export type FlagPointsForInspectionInput = z.infer<typeof FlagPointsForInspectionInputSchema>;

const FlagPointsForInspectionOutputSchema = z.object({
  pointsNeedingInspection: z.array(z.string()).describe('Array of anchor point IDs that require inspection.'),
});

export type FlagPointsForInspectionOutput = z.infer<typeof FlagPointsForInspectionOutputSchema>;

export async function flagPointsForInspection(input: FlagPointsForInspectionInput): Promise<FlagPointsForInspectionOutput> {
  return flagPointsForInspectionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'flagPointsForInspectionPrompt',
  input: {schema: FlagPointsForInspectionInputSchema},
  output: {schema: FlagPointsForInspectionOutputSchema},
  prompt: `You are a safety manager responsible for flagging anchor points that require inspection.

  Based on the anchor point type, installation date, last inspection date (if available), and inspection frequency, determine which anchor points need inspection.

  Here are the anchor points:
  {{#each anchorPoints}}
  - ID: {{this.id}}, Type: {{this.type}}, Installation Date: {{this.installationDate}}, Last Inspection Date: {{this.lastInspectionDate}}, Inspection Frequency: {{this.inspectionFrequencyMonths}} months
  {{/each}}

  Return only the IDs of the anchor points that require inspection.
  `,
});

const flagPointsForInspectionFlow = ai.defineFlow(
  {
    name: 'flagPointsForInspectionFlow',
    inputSchema: FlagPointsForInspectionInputSchema,
    outputSchema: FlagPointsForInspectionOutputSchema,
  },
  async input => {
    const now = new Date();
    const pointsNeedingInspection: string[] = [];

    for (const point of input.anchorPoints) {
      const installationDate = new Date(point.installationDate);
      const monthsSinceInstallation = (now.getFullYear() - installationDate.getFullYear()) * 12 +
        (now.getMonth() - installationDate.getMonth());

      let monthsSinceLastInspection = monthsSinceInstallation;

      if (point.lastInspectionDate) {
        const lastInspectionDate = new Date(point.lastInspectionDate);
        monthsSinceLastInspection = (now.getFullYear() - lastInspectionDate.getFullYear()) * 12 +
          (now.getMonth() - lastInspectionDate.getMonth());
      }

      if (monthsSinceLastInspection >= point.inspectionFrequencyMonths) {
        pointsNeedingInspection.push(point.id);
      }
    }

    return {pointsNeedingInspection};
  }
);
